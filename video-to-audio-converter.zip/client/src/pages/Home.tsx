import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState, useRef, useEffect } from "react";
import { Upload, Download, Play, Loader2, AlertCircle, CheckCircle } from "lucide-react";

interface FileMetadata {
  fileName: string;
  fileSize: number;
  duration: number;
  format: string;
  filePath: string;
}

interface ConversionState {
  id?: number;
  status: "idle" | "uploading" | "processing" | "completed" | "error";
  progress: number;
  error?: string;
  outputUrl?: string;
  outputFileSize?: number;
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoPreviewRef = useRef<HTMLVideoElement>(null);

  // State management
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [conversionState, setConversionState] = useState<ConversionState>({ status: "idle", progress: 0 });
  const [outputFormat, setOutputFormat] = useState<string>("mp3");
  const [audioBitrate, setAudioBitrate] = useState<string>("192");
  const [audioSampleRate, setAudioSampleRate] = useState<string>("44100");
  const [audioChannel, setAudioChannel] = useState<string>("stereo");

  // tRPC mutations
  const startConversion = trpc.conversion.startConversion.useMutation();
  const getProgress = trpc.conversion.getProgress.useQuery(
    { id: conversionState.id || 0 },
    { enabled: !!conversionState.id && conversionState.status === "processing", refetchInterval: 1000 }
  ) as any;

  // Handle file selection
  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setConversionState({ status: "uploading", progress: 0 });

    try {
      const formData = new FormData();
      formData.append("video", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const metadata = (await response.json()) as FileMetadata;
      setFileMetadata(metadata);

      // Set up video preview
      if (videoPreviewRef.current) {
        videoPreviewRef.current.src = URL.createObjectURL(file);
      }

      setConversionState({ status: "idle", progress: 0 });
      toast.success("File uploaded successfully");
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Upload failed";
      setConversionState({ status: "error", progress: 0, error: errorMessage });
      toast.error(errorMessage);
    }
  };

  // Handle drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.add("border-blue-500", "bg-blue-50");
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.currentTarget.classList.remove("border-blue-500", "bg-blue-50");
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.remove("border-blue-500", "bg-blue-50");

    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (fileInputRef.current) {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        fileInputRef.current.files = dataTransfer.files;
        handleFileSelect({ target: fileInputRef.current } as any);
      }
    }
  };

  // Handle conversion start
  const handleConvertClick = async () => {
    if (!fileMetadata || !user) return;

    setConversionState({ status: "processing", progress: 10 });

    try {
      const result = await startConversion.mutateAsync({
        fileName: fileMetadata.fileName,
        fileSize: fileMetadata.fileSize,
        videoDuration: fileMetadata.duration,
        inputFormat: fileMetadata.format,
        outputFormat: outputFormat as any,
        audioBitrate: parseInt(audioBitrate) as any,
        audioSampleRate: parseInt(audioSampleRate) as any,
        audioChannel: audioChannel as "mono" | "stereo",
        filePath: fileMetadata.filePath,
      });

      setConversionState({
        id: result.id,
        status: "processing",
        progress: 20,
      });

      toast.success("Conversion started");
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Conversion failed";
      setConversionState({ status: "error", progress: 0, error: errorMessage });
      toast.error(errorMessage);
    }
  };

  // Monitor conversion progress
  useEffect(() => {
    if (getProgress.data) {
      const { status, errorMessage, outputFileKey, outputFileSize } = getProgress.data;

      if (status === "completed") {
        setConversionState({
          id: conversionState.id,
          status: "completed",
          progress: 100,
          outputUrl: outputFileKey ? `/manus-storage/${outputFileKey}` : undefined,
          outputFileSize: outputFileSize ? Number(outputFileSize) : undefined,
        });
        toast.success("Conversion completed!");
      } else if (status === "failed") {
        setConversionState({
          id: conversionState.id,
          status: "error",
          progress: 0,
          error: errorMessage || "Conversion failed",
        });
        toast.error(errorMessage || "Conversion failed");
      } else if (status === "processing") {
        setConversionState((prev) => ({
          ...prev,
          progress: Math.min(prev.progress + 5, 95),
        }));
      }
    }
  }, [getProgress.data]);

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  };

  // Format duration
  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    }
    return `${minutes}m ${secs}s`;
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center px-4">
        <Card className="w-full max-w-md p-8 bg-slate-800 border-slate-700">
          <div className="text-center space-y-6">
            <div className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Video to Audio
            </div>
            <p className="text-slate-300">Sign in to convert your videos to audio</p>
            <Button
              onClick={() => (window.location.href = getLoginUrl())}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
            >
              Sign In
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Video to Audio Converter
            </div>
            <div className="text-slate-300 text-sm">Welcome, {user?.name}</div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upload Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* Drag & Drop Area */}
            <Card
              className="border-2 border-dashed border-slate-600 bg-slate-800/50 p-12 text-center cursor-pointer hover:border-blue-400 hover:bg-slate-800 transition-all"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                onChange={handleFileSelect}
                className="hidden"
              />
              <div className="space-y-4">
                <Upload className="w-16 h-16 mx-auto text-blue-400" />
                <div>
                  <p className="text-lg font-semibold text-slate-100">Drag and drop your video here</p>
                  <p className="text-slate-400 text-sm mt-2">or click the button below (up to 5GB)</p>
                </div>
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Choose File
                </Button>
              </div>
            </Card>

            {/* File Info */}
            {fileMetadata && (
              <Card className="bg-slate-800 border-slate-700 p-6 space-y-4">
                <div className="space-y-2">
                  <p className="text-sm text-slate-400">File Name</p>
                  <p className="font-semibold text-slate-100">{fileMetadata.fileName}</p>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-slate-400">File Size</p>
                    <p className="font-semibold text-slate-100">{formatFileSize(fileMetadata.fileSize)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Duration</p>
                    <p className="font-semibold text-slate-100">{formatDuration(fileMetadata.duration)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Format</p>
                    <p className="font-semibold text-slate-100">{fileMetadata.format.toUpperCase()}</p>
                  </div>
                </div>
              </Card>
            )}

            {/* Video Preview */}
            {fileMetadata && (
              <Card className="bg-slate-800 border-slate-700 p-6">
                <p className="text-sm text-slate-400 mb-4">Preview</p>
                <video
                  ref={videoPreviewRef}
                  className="w-full rounded-lg bg-black"
                  controls
                  style={{ maxHeight: "300px" } as any}
                />
              </Card>
            )}

            {/* Conversion Progress */}
            {conversionState.status !== "idle" && (
              <Card className="bg-slate-800 border-slate-700 p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <p className="font-semibold text-slate-100">
                    {conversionState.status === "uploading" && "Uploading..."}
                    {conversionState.status === "processing" && "Converting..."}
                    {conversionState.status === "completed" && "Completed!"}
                    {conversionState.status === "error" && "Error"}
                  </p>
                  {conversionState.status === "processing" && <Loader2 className="w-5 h-5 animate-spin text-blue-400" />}
                  {conversionState.status === "completed" && <CheckCircle className="w-5 h-5 text-green-400" />}
                  {conversionState.status === "error" && <AlertCircle className="w-5 h-5 text-red-400" />}
                </div>
                <Progress value={conversionState.progress} className="h-2" />
                <p className="text-sm text-slate-400">{conversionState.progress}% complete</p>
              </Card>
            )}
          </div>

          {/* Settings Section */}
          <div className="space-y-6">
            <Card className="bg-slate-800 border-slate-700 p-6 space-y-6">
              <h3 className="font-semibold text-slate-100">Audio Settings</h3>

              {/* Output Format */}
              <div className="space-y-2">
                <label className="text-sm text-slate-400">Output Format</label>
                <Select value={outputFormat} onValueChange={setOutputFormat} disabled={conversionState.status !== "idle"}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-slate-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="mp3">MP3</SelectItem>
                    <SelectItem value="wav">WAV</SelectItem>
                    <SelectItem value="aac">AAC</SelectItem>
                    <SelectItem value="flac">FLAC</SelectItem>
                    <SelectItem value="ogg">OGG</SelectItem>
                    <SelectItem value="m4a">M4A</SelectItem>
                    <SelectItem value="opus">OPUS</SelectItem>
                    <SelectItem value="aiff">AIFF</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Bitrate */}
              <div className="space-y-2">
                <label className="text-sm text-slate-400">Quality (Bitrate)</label>
                <Select value={audioBitrate} onValueChange={setAudioBitrate} disabled={conversionState.status !== "idle"}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-slate-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="64">64 kbps</SelectItem>
                    <SelectItem value="128">128 kbps</SelectItem>
                    <SelectItem value="192">192 kbps</SelectItem>
                    <SelectItem value="256">256 kbps</SelectItem>
                    <SelectItem value="320">320 kbps</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Sample Rate */}
              <div className="space-y-2">
                <label className="text-sm text-slate-400">Sample Rate</label>
                <Select value={audioSampleRate} onValueChange={setAudioSampleRate} disabled={conversionState.status !== "idle"}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-slate-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="44100">44100 Hz</SelectItem>
                    <SelectItem value="48000">48000 Hz</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Channel */}
              <div className="space-y-2">
                <label className="text-sm text-slate-400">Channel</label>
                <Select value={audioChannel} onValueChange={setAudioChannel} disabled={conversionState.status !== "idle"}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-slate-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="mono">Mono</SelectItem>
                    <SelectItem value="stereo">Stereo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Convert Button */}
              <Button
                onClick={handleConvertClick}
                disabled={!fileMetadata || conversionState.status !== "idle"}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 disabled:opacity-50"
              >
                {conversionState.status === "processing" ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Converting...
                  </>
                ) : (
                  "Convert"
                )}
              </Button>

              {/* Download Button */}
              {conversionState.status === "completed" && conversionState.outputUrl && (
                <a href={conversionState.outputUrl} download className="block">
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    <Download className="w-4 h-4 mr-2" />
                    Download Audio
                  </Button>
                </a>
              )}
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-800/50 mt-12">
        <div className="max-w-6xl mx-auto px-4 py-6 text-center text-slate-400 text-sm">
          Powered by FFmpeg
        </div>
      </footer>
    </div>
  );
}
