import express, { Request, Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs/promises";
import { getVideoDuration, getVideoFormat } from "../services/ffmpegService";

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), "uploads");
    try {
      await fs.mkdir(uploadDir, { recursive: true });
      cb(null, uploadDir);
    } catch (error) {
      cb(error as Error, "");
    }
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024 * 1024, // 5GB
  },
  fileFilter: (req, file, cb) => {
    // Allowed video formats
    const allowedMimes = [
      "video/mp4",
      "video/x-msvideo",
      "video/x-matroska",
      "video/quicktime",
      "video/webm",
      "video/x-flv",
      "video/x-ms-wmv",
      "video/mpeg",
      "video/3gpp",
      "video/mp2t",
    ];

    if (allowedMimes.includes(file.mimetype) || file.mimetype.startsWith("video/")) {
      cb(null, true);
    } else {
      cb(new Error(`Invalid file type: ${file.mimetype}`));
    }
  },
});

/**
 * POST /api/upload
 * Upload a video file and get metadata
 */
router.post("/", upload.single("video"), async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const filePath = req.file.path;
    const fileName = req.file.originalname;
    const fileSize = req.file.size;

    // Get video metadata
    let duration = 0;
    let format = "unknown";

    try {
      duration = await getVideoDuration(filePath);
      format = await getVideoFormat(filePath);
    } catch (error) {
      console.error("Error getting video metadata:", error);
      // Continue anyway, metadata is optional
    }

    res.json({
      fileName,
      fileSize,
      duration,
      format,
      filePath, // Return path for backend use
    });
  } catch (error) {
    console.error("Upload error:", error);
    res.status(500).json({
      error: error instanceof Error ? error.message : "Upload failed",
    });
  }
});

export default router;
