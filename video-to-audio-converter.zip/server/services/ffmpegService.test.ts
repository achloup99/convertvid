import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { getVideoDuration, getVideoFormat, buildFFmpegCommand } from "./ffmpegService";
import fs from "fs/promises";
import path from "path";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

describe("FFmpeg Service", () => {
  let testVideoPath: string;

  beforeAll(async () => {
    // Create a test video file using FFmpeg
    testVideoPath = path.join("/tmp", "test-video.mp4");
    
    try {
      // Generate a 5-second test video
      await execAsync(
        `ffmpeg -f lavfi -i testsrc=duration=5:size=320x240:rate=1 -f lavfi -i sine=frequency=1000:duration=5 -pix_fmt yuv420p -y "${testVideoPath}"`,
        { timeout: 30000 }
      );
    } catch (error) {
      console.warn("Could not create test video:", error);
    }
  });

  afterAll(async () => {
    // Clean up test video
    try {
      await fs.unlink(testVideoPath);
    } catch {}
  });

  describe("getVideoDuration", () => {
    it("should return video duration in seconds", async () => {
      if (!fs.stat(testVideoPath).catch(() => null)) {
        console.log("Skipping test - test video not available");
        return;
      }

      const duration = await getVideoDuration(testVideoPath);
      expect(typeof duration).toBe("number");
      expect(duration).toBeGreaterThan(0);
      expect(duration).toBeLessThanOrEqual(6); // Allow some margin
    });

    it("should throw error for non-existent file", async () => {
      await expect(getVideoDuration("/tmp/non-existent-video.mp4")).rejects.toThrow();
    });
  });

  describe("getVideoFormat", () => {
    it("should return video format", async () => {
      if (!fs.stat(testVideoPath).catch(() => null)) {
        console.log("Skipping test - test video not available");
        return;
      }

      const format = await getVideoFormat(testVideoPath);
      expect(typeof format).toBe("string");
      expect(format.length).toBeGreaterThan(0);
    });
  });

  describe("Audio Conversion Options", () => {
    it("should support all audio formats", () => {
      const formats = ["mp3", "wav", "aac", "flac", "ogg", "m4a", "opus", "aiff"];
      expect(formats).toContain("mp3");
      expect(formats).toContain("wav");
      expect(formats).toContain("aac");
      expect(formats).toContain("flac");
      expect(formats).toContain("ogg");
      expect(formats).toContain("m4a");
      expect(formats).toContain("opus");
      expect(formats).toContain("aiff");
    });

    it("should support all bitrates", () => {
      const bitrates = [64, 128, 192, 256, 320];
      expect(bitrates).toEqual([64, 128, 192, 256, 320]);
    });

    it("should support all sample rates", () => {
      const sampleRates = [44100, 48000];
      expect(sampleRates).toEqual([44100, 48000]);
    });

    it("should support mono and stereo channels", () => {
      const channels = ["mono", "stereo"];
      expect(channels).toEqual(["mono", "stereo"]);
    });
  });
});
