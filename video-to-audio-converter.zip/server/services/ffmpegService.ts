import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs/promises";
import path from "path";

const execAsync = promisify(exec);

/**
 * Audio conversion options
 */
export interface AudioConversionOptions {
  format: string;
  bitrate: number; // in kbps
  sampleRate: number; // in Hz
  channel: "mono" | "stereo";
}

/**
 * Get video duration in seconds using FFprobe
 */
export async function getVideoDuration(filePath: string): Promise<number> {
  try {
    const { stdout } = await execAsync(
      `ffprobe -v error -select_streams v:0 -show_entries format=duration -of csv=p=0 "${filePath}"`
    );
    const duration = parseFloat(stdout.trim());
    return Math.ceil(duration);
  } catch (error) {
    console.error("[FFprobe] Failed to get duration:", error);
    throw new Error("Failed to get video duration");
  }
}

/**
 * Get video format information
 */
export async function getVideoFormat(filePath: string): Promise<string> {
  try {
    const { stdout } = await execAsync(
      `ffprobe -v error -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 "${filePath}"`
    );
    return stdout.trim() || "unknown";
  } catch (error) {
    console.error("[FFprobe] Failed to get format:", error);
    return "unknown";
  }
}

/**
 * Convert video file to audio file using FFmpeg
 */
export async function convertVideoToAudio(
  inputPath: string,
  outputPath: string,
  options: AudioConversionOptions
): Promise<void> {
  try {
    // Validate input file exists
    await fs.access(inputPath);

    // Build FFmpeg command with appropriate codec and options
    const ffmpegCmd = buildFFmpegCommand(inputPath, outputPath, options);

    console.log(`[FFmpeg] Starting conversion: ${inputPath} -> ${outputPath}`);
    console.log(`[FFmpeg] Command: ${ffmpegCmd}`);

    const { stdout, stderr } = await execAsync(ffmpegCmd, {
      maxBuffer: 10 * 1024 * 1024, // 10MB buffer for large files
      timeout: 3600000, // 1 hour timeout
    });

    // Verify output file was created
    const stats = await fs.stat(outputPath);
    if (stats.size === 0) {
      throw new Error("Output file is empty");
    }

    console.log(`[FFmpeg] Conversion completed successfully. Output size: ${stats.size} bytes`);
  } catch (error) {
    console.error("[FFmpeg] Conversion failed:", error);
    
    // Clean up partial output file
    try {
      await fs.unlink(outputPath);
    } catch {}
    
    throw error;
  }
}

/**
 * Build FFmpeg command based on output format and options
 */
function buildFFmpegCommand(
  inputPath: string,
  outputPath: string,
  options: AudioConversionOptions
): string {
  const { format, bitrate, sampleRate, channel } = options;

  // Escape paths for shell
  const escapedInput = `"${inputPath}"`;
  const escapedOutput = `"${outputPath}"`;

  // Base command
  let cmd = `ffmpeg -i ${escapedInput}`;

  // Add audio codec based on format
  switch (format.toLowerCase()) {
    case "mp3":
      cmd += " -codec:a libmp3lame";
      break;
    case "wav":
      cmd += " -codec:a pcm_s16le";
      break;
    case "aac":
      cmd += " -codec:a aac";
      break;
    case "flac":
      cmd += " -codec:a flac";
      break;
    case "ogg":
      cmd += " -codec:a libvorbis";
      break;
    case "m4a":
      cmd += " -codec:a aac";
      break;
    case "opus":
      cmd += " -codec:a libopus";
      break;
    case "aiff":
      cmd += " -codec:a pcm_s16be";
      break;
    default:
      cmd += " -codec:a libmp3lame";
  }

  // Add bitrate
  cmd += ` -b:a ${bitrate}k`;

  // Add sample rate
  cmd += ` -ar ${sampleRate}`;

  // Add channels
  if (channel === "mono") {
    cmd += " -ac 1";
  } else {
    cmd += " -ac 2";
  }

  // Remove video stream
  cmd += " -vn";

  // Overwrite output file without asking
  cmd += " -y";

  // Add output path
  cmd += ` ${escapedOutput}`;

  return cmd;
}

/**
 * Get audio file information
 */
export async function getAudioInfo(filePath: string): Promise<{
  duration: number;
  bitrate: number;
  sampleRate: number;
  channels: number;
}> {
  try {
    const { stdout } = await execAsync(
      `ffprobe -v error -select_streams a:0 -show_entries stream=duration,bit_rate,sample_rate,channels -of csv=p=0 "${filePath}"`
    );

    const values = stdout.trim().split(",");
    return {
      duration: Math.ceil(parseFloat(values[0] || "0")),
      bitrate: parseInt(values[1] || "0"),
      sampleRate: parseInt(values[2] || "44100"),
      channels: parseInt(values[3] || "2"),
    };
  } catch (error) {
    console.error("[FFprobe] Failed to get audio info:", error);
    throw new Error("Failed to get audio information");
  }
}
