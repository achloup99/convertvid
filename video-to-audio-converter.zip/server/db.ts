import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, conversions, InsertConversion, Conversion } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Create a new conversion record
 */
export async function createConversion(data: InsertConversion): Promise<Conversion | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create conversion: database not available");
    return undefined;
  }

  try {
    const result = await db.insert(conversions).values(data);
    const id = (result as any).insertId;
    const created = await db.select().from(conversions).where(eq(conversions.id, id)).limit(1);
    return created.length > 0 ? created[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to create conversion:", error);
    throw error;
  }
}

/**
 * Update a conversion record
 */
export async function updateConversion(id: number, data: Partial<InsertConversion>): Promise<Conversion | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update conversion: database not available");
    return undefined;
  }

  try {
    await db.update(conversions).set(data).where(eq(conversions.id, id));
    const updated = await db.select().from(conversions).where(eq(conversions.id, id)).limit(1);
    return updated.length > 0 ? updated[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to update conversion:", error);
    throw error;
  }
}

/**
 * Get conversion by ID
 */
export async function getConversionById(id: number): Promise<Conversion | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get conversion: database not available");
    return undefined;
  }

  try {
    const result = await db.select().from(conversions).where(eq(conversions.id, id)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get conversion:", error);
    throw error;
  }
}

/**
 * Get all conversions for a user
 */
export async function getUserConversions(userId: number, limit: number = 50): Promise<Conversion[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get conversions: database not available");
    return [];
  }

  try {
    return await db
      .select()
      .from(conversions)
      .where(eq(conversions.userId, userId))
      .orderBy(desc(conversions.createdAt))
      .limit(limit);
  } catch (error) {
    console.error("[Database] Failed to get user conversions:", error);
    throw error;
  }
}
