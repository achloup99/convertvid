import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { createConversion, updateConversion, getConversionById, getUserConversions } from "../db";
import { convertVideoToAudio } from "../services/ffmpegService";
import { storagePut } from "../storage";
import fs from "fs/promises";
import path from "path";

// Validation schemas
const audioFormatSchema = z.enum(["mp3", "wav", "aac", "flac", "ogg", "m4a", "opus", "aiff"]);
const bitrateSchema = z.enum(["64", "128", "192", "256", "320"]).transform(Number);
const sampleRateSchema = z.enum(["44100", "48000"]).transform(Number);
const channelSchema = z.enum(["mono", "stereo"]);

export const conversionRouter = router({
  /**
   * Get conversion history for the current user
   */
  getHistory: protectedProcedure
    .input(z.object({ limit: z.number().min(1).max(100).default(50) }))
    .query(async ({ ctx, input }) => {
      return await getUserConversions(ctx.user.id, input.limit);
    }),

  /**
   * Get a specific conversion by ID
   */
  getById: protectedProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const conversion = await getConversionById(input.id);
      
      // Verify ownership
      if (conversion && conversion.userId !== ctx.user.id) {
        throw new Error("Unauthorized");
      }
      
      return conversion;
    }),

  /**
   * Start a video to audio conversion
   * Expects the video file to be uploaded separately
   */
  startConversion: protectedProcedure
    .input(
      z.object({
        fileName: z.string().min(1).max(255),
        fileSize: z.number().int().positive(),
        videoDuration: z.number().int().positive(),
        inputFormat: z.string().min(2).max(10),
        outputFormat: audioFormatSchema,
        audioBitrate: bitrateSchema,
        audioSampleRate: sampleRateSchema,
        audioChannel: channelSchema,
        filePath: z.string(), // Temporary file path
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // Create conversion record in database
        const conversion = await createConversion({
          userId: ctx.user.id,
          originalFileName: input.fileName,
          originalFileSize: input.fileSize as any,
          videoDuration: input.videoDuration,
          inputFormat: input.inputFormat,
          outputFormat: input.outputFormat,
          audioBitrate: input.audioBitrate,
          audioSampleRate: input.audioSampleRate,
          audioChannel: input.audioChannel,
          status: "processing",
        });

        if (!conversion) {
          throw new Error("Failed to create conversion record");
        }

        // Start async conversion process
        // Don't await this - let it run in the background
        performConversion(conversion.id, input.filePath, input.outputFormat, {
          bitrate: input.audioBitrate,
          sampleRate: input.audioSampleRate,
          channel: input.audioChannel,
        }).catch((error) => {
          console.error(`[Conversion ${conversion.id}] Error:`, error);
          updateConversion(conversion.id, {
            status: "failed",
            errorMessage: error instanceof Error ? error.message : "Unknown error",
          }).catch(console.error);
        });

        return {
          id: conversion.id,
          status: conversion.status,
        };
      } catch (error) {
        console.error("[Conversion] Start error:", error);
        throw error;
      }
    }),

  /**
   * Get conversion progress (for polling)
   */
  getProgress: protectedProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const conversion = await getConversionById(input.id);
      
      if (!conversion) {
        throw new Error("Conversion not found");
      }

      // Verify ownership
      if (conversion.userId !== ctx.user.id) {
        throw new Error("Unauthorized");
      }

      return {
        id: conversion.id,
        status: conversion.status,
        errorMessage: conversion.errorMessage,
        outputFileKey: conversion.outputFileKey,
        outputFileSize: conversion.outputFileSize,
      };
    }),
});

/**
 * Perform the actual video to audio conversion
 * This runs asynchronously in the background
 */
async function performConversion(
  conversionId: number,
  inputFilePath: string,
  outputFormat: string,
  audioOptions: {
    bitrate: number;
    sampleRate: number;
    channel: "mono" | "stereo";
  }
) {
  try {
    // Convert video to audio using FFmpeg
    const outputFileName = `conversion-${conversionId}.${outputFormat}`;
    const outputFilePath = path.join("/tmp", outputFileName);

    await convertVideoToAudio(inputFilePath, outputFilePath, {
      format: outputFormat,
      bitrate: audioOptions.bitrate,
      sampleRate: audioOptions.sampleRate,
      channel: audioOptions.channel,
    });

    // Get output file size
    const stats = await fs.stat(outputFilePath);
    const outputFileSize = stats.size;

    // Upload to storage
    const fileBuffer = await fs.readFile(outputFilePath);
    const storageKey = `conversions/${conversionId}/${outputFileName}`;
    const { key } = await storagePut(storageKey, fileBuffer, `audio/${outputFormat}`);

    // Update conversion record
    await updateConversion(conversionId, {
      status: "completed",
      outputFileSize: outputFileSize as any,
      outputFileKey: key,
    });

    // Clean up temporary files
    await fs.unlink(inputFilePath).catch(() => {});
    await fs.unlink(outputFilePath).catch(() => {});
  } catch (error) {
    console.error(`[Conversion ${conversionId}] Conversion failed:`, error);
    throw error;
  }
}
