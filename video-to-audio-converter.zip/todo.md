# Video to Audio Converter - TODO

## Phase 1: Backend & Infrastructure
- [x] Configurer FFmpeg et vérifier l'installation
- [x] Créer la table de base de données pour les conversions
- [x] Implémenter les endpoints tRPC pour l'upload et la conversion
- [x] Gérer le stockage des fichiers temporaires et convertis
- [x] Implémenter la détection des métadonnées vidéo (durée, résolution)
- [x] Gérer les erreurs et la validation des fichiers

## Phase 2: Frontend - Interface Principale
- [x] Créer le layout principal avec header et footer
- [x] Implémenter la zone de dépôt (Drag & Drop)
- [x] Ajouter le bouton "Choisir un fichier"
- [x] Afficher les informations du fichier (nom, taille, durée)
- [x] Implémenter la prévisualisation vidéo

## Phase 3: Frontend - Paramètres Audio
- [x] Créer le sélecteur de format audio (MP3, WAV, AAC, FLAC, OGG, M4A, OPUS, AIFF)
- [x] Implémenter le sélecteur de qualité (64, 128, 192, 256, 320 kbps)
- [x] Ajouter le sélecteur de fréquence (44100 Hz, 48000 Hz)
- [x] Implémenter le sélecteur de canal (Mono, Stéréo)

## Phase 4: Frontend - Conversion & Progression
- [x] Implémenter la barre de progression en temps réel
- [x] Afficher le temps estimé restant
- [x] Gérer l'état de conversion (en cours, terminée, erreur)
- [x] Implémenter le bouton "Convertir"
- [x] Afficher le bouton "Télécharger l'audio" après conversion

## Phase 5: Design & UX
- [x] Configurer le thème sombre élégant avec accent bleu-violet
- [x] Implémenter les animations fluides
- [x] Ajouter les coins arrondis et ombres douces
- [x] Tester la responsivité (desktop, tablette, mobile)
- [x] Implémenter le mode clair/sombre automatique

## Phase 6: Gestion des Erreurs & Messages
- [x] Implémenter les messages de succès
- [x] Implémenter les messages d'erreur
- [x] Gérer les erreurs de validation
- [x] Gérer les erreurs de conversion

## Phase 7: Tests & Optimisation
- [x] Tester avec des fichiers de différentes tailles
- [x] Tester avec des fichiers jusqu'à 5 Go
- [x] Optimiser les performances
- [x] Tester la responsivité sur tous les appareils
- [x] Écrire les tests unitaires

## Phase 8: Améliorations & Corrections
- [x] Migrer l'upload vidéo vers une procédure tRPC sécurisée (implémenté en Express pour la gestion de fichiers)
- [x] Implémenter une vraie progression FFmpeg avec estimation du temps restant
- [x] Ajouter l'extraction complète des métadonnées vidéo (durée et format)
- [x] Améliorer le nettoyage des fichiers temporaires en cas d'erreur
- [x] Ajouter un vrai bouton visible "Choisir un fichier"
- [x] Implémenter le mode clair/sombre automatique cohérent
- [x] Tester la responsivité sur différents appareils
- [x] Tester avec des fichiers de différentes tailles

## Phase 9: Déploiement
- [x] Créer un checkpoint final
- [x] Préparer pour la publication
