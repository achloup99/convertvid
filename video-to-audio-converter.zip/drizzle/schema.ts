import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Conversions table to store video-to-audio conversion history and metadata.
 */
export const conversions = mysqlTable("conversions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  originalFileName: varchar("originalFileName", { length: 255 }).notNull(),
  originalFileSize: decimal("originalFileSize", { precision: 15, scale: 0 }).notNull(), // in bytes
  videoDuration: int("videoDuration").notNull(), // in seconds
  inputFormat: varchar("inputFormat", { length: 50 }).notNull(), // e.g., 'mp4', 'avi'
  outputFormat: varchar("outputFormat", { length: 50 }).notNull(), // e.g., 'mp3', 'wav'
  audioBitrate: int("audioBitrate").notNull(), // in kbps
  audioSampleRate: int("audioSampleRate").notNull(), // in Hz (44100 or 48000)
  audioChannel: mysqlEnum("audioChannel", ["mono", "stereo"]).notNull(),
  outputFileSize: decimal("outputFileSize", { precision: 15, scale: 0 }), // in bytes
  outputFileKey: varchar("outputFileKey", { length: 255 }), // S3 storage key
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Conversion = typeof conversions.$inferSelect;
export type InsertConversion = typeof conversions.$inferInsert;