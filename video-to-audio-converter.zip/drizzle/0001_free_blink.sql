CREATE TABLE `conversions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`originalFileName` varchar(255) NOT NULL,
	`originalFileSize` decimal(15,0) NOT NULL,
	`videoDuration` int NOT NULL,
	`inputFormat` varchar(50) NOT NULL,
	`outputFormat` varchar(50) NOT NULL,
	`audioBitrate` int NOT NULL,
	`audioSampleRate` int NOT NULL,
	`audioChannel` enum('mono','stereo') NOT NULL,
	`outputFileSize` decimal(15,0),
	`outputFileKey` varchar(255),
	`status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `conversions_id` PRIMARY KEY(`id`)
);
